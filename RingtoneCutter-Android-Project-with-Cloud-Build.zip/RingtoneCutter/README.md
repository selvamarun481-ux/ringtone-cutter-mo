# Ringtone Cutter (Android)

A starter Android Studio project for a dark-themed audio trimming app.

## Included in v1 starter
- Pick an audio file using Android's system document picker
- Display selected file name and duration
- Choose start and end positions
- Preview the selected audio (preview starts at the chosen start position)
- Export the selected clip as an M4A/AAC file using AndroidX Media3 Transformer

## Open and run
1. Install Android Studio (Ladybug or newer recommended).
2. Open this folder (`RingtoneCutter`) in Android Studio.
3. Allow Gradle to sync and install Android SDK 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run.

## Notes
- This is a source-code starter project, not an installed APK.
- Exported clips are placed in the app-specific Music folder. Android may remove app-specific files when the app is uninstalled.
- The first version exports M4A/AAC in an MP4-family container. MP3 export, waveform rendering, media-library saving, and direct “Set as ringtone” integration are planned enhancements.
- Audio access uses Android's system picker, so broad storage permissions are not needed.
