package com.example.ringtonecutter

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var selectedUri: Uri? = null
    private var player: MediaPlayer? = null
    private var durationMs = 0
    private var startMs = 0
    private var endMs = 0
    private lateinit var songName: TextView
    private lateinit var durationLabel: TextView
    private lateinit var startLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var startSeek: SeekBar
    private lateinit var endSeek: SeekBar
    private lateinit var playButton: Button
    private lateinit var saveButton: Button
    private var transformer: Transformer? = null

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadAudio(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(0xFF10151D.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val green = 0xFF58E6A0.toInt()
        val white = 0xFFF4F7FA.toInt()
        val muted = 0xFFAAB5C2.toInt()

        root.addView(text("♫  Ringtone Cutter", 25f, white, true))
        root.addView(text("Your music. Your perfect ringtone.", 13f, muted).apply { setPadding(0, dp(5), 0, dp(22)) })

        val choose = Button(this).apply {
            text = "＋   Choose Audio"
            setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }
        }
        root.addView(choose, matchWrap())

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(0xFF1C2733.toInt())
        }
        val panelParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) }
        root.addView(panel, panelParams)
        panel.addView(text("NOW EDITING", 11f, green, true))
        songName = text("No audio selected", 19f, white, true)
        songName.setPadding(0, dp(8), 0, dp(4))
        panel.addView(songName)
        durationLabel = text("Duration: 00:00", 12f, muted)
        panel.addView(durationLabel)

        panel.addView(text("Start position", 13f, white, true).apply { setPadding(0, dp(20), 0, 0) })
        startLabel = text("00:00", 12f, green)
        panel.addView(startLabel)
        startSeek = SeekBar(this).apply { max = 1000; progressTintList = android.content.res.ColorStateList.valueOf(green); thumbTintList = android.content.res.ColorStateList.valueOf(green) }
        panel.addView(startSeek)
        panel.addView(text("End position", 13f, white, true).apply { setPadding(0, dp(12), 0, 0) })
        endLabel = text("00:00", 12f, green)
        panel.addView(endLabel)
        endSeek = SeekBar(this).apply { max = 1000; progress = 1000; progressTintList = android.content.res.ColorStateList.valueOf(green); thumbTintList = android.content.res.ColorStateList.valueOf(green) }
        panel.addView(endSeek)

        startSeek.setOnSeekBarChangeListener(seekListener { value ->
            startMs = (durationMs * value / 1000f).toInt().coerceAtMost((endMs - 1000).coerceAtLeast(0))
            startLabel.text = formatTime(startMs)
        })
        endSeek.setOnSeekBarChangeListener(seekListener { value ->
            endMs = (durationMs * value / 1000f).toInt().coerceAtLeast((startMs + 1000).coerceAtMost(durationMs))
            endLabel.text = formatTime(endMs)
        })

        playButton = Button(this).apply {
            text = "▶   Preview"
            isEnabled = false
            setOnClickListener { previewSelection() }
        }
        val previewParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        panel.addView(playButton, previewParams)

        saveButton = Button(this).apply {
            text = "Save Ringtone"
            isEnabled = false
            setOnClickListener { exportAudio() }
        }
        val saveParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        root.addView(saveButton, saveParams)
        root.addView(text("Select a song, choose the start and end, preview, then save.", 12f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0)
        })
        setContentView(root)
    }

    private fun loadAudio(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        selectedUri = uri
        try {
            val mp = MediaPlayer.create(this, uri) ?: throw IllegalStateException("Can't open this audio file")
            durationMs = mp.duration
            mp.release()
            startMs = 0
            endMs = durationMs
            startSeek.progress = 0
            endSeek.progress = 1000
            startLabel.text = formatTime(startMs)
            endLabel.text = formatTime(endMs)
            durationLabel.text = "Duration: ${formatTime(durationMs)}"
            songName.text = queryDisplayName(uri) ?: "Selected audio"
            playButton.isEnabled = true
            saveButton.isEnabled = true
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to read this audio file", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun previewSelection() {
        val uri = selectedUri ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp -> mp.seekTo(startMs); mp.start(); playButton.text = "Playing preview…" }
                setOnCompletionListener { playButton.text = "▶   Preview" }
                prepareAsync()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Preview failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportAudio() {
        val uri = selectedUri ?: return
        if (endMs <= startMs) {
            Toast.makeText(this, "Choose a valid audio range", Toast.LENGTH_SHORT).show(); return
        }
        val folder = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
        val output = File(folder, "Ringtone_${System.currentTimeMillis()}.m4a")
        saveButton.isEnabled = false
        saveButton.text = "Creating ringtone…"
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs.toLong())
            .setEndPositionMs(endMs.toLong())
            .build()
        val item = EditedMediaItem.Builder(MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()).build()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                runOnUiThread {
                    saveButton.isEnabled = true; saveButton.text = "Save Ringtone"
                    Toast.makeText(this@MainActivity, "Saved: ${output.name}\nApp Music folder", Toast.LENGTH_LONG).show()
                }
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                runOnUiThread {
                    saveButton.isEnabled = true; saveButton.text = "Save Ringtone"
                    Toast.makeText(this@MainActivity, "Export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        transformer = Transformer.Builder(this).addListener(listener).build()
        try { transformer?.start(item, output.absolutePath) }
        catch (e: Exception) {
            saveButton.isEnabled = true; saveButton.text = "Save Ringtone"
            Toast.makeText(this, "Could not start export: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser && durationMs > 0) onChange(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun formatTime(ms: Int): String {
        val total = ms / 1000
        return String.format(Locale.getDefault(), "%02d:%02d", total / 60, total % 60)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    override fun onDestroy() {
        player?.release(); player = null
        transformer?.cancel()
        super.onDestroy()
    }
}
